import os
import json
import sys
import time
import asyncio
from datetime import datetime
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor

# Import TextBlob for local sentiment analysis
from textblob import TextBlob

# Pydroid-specific path insertion (ensure this is correct for your environment)
PROJECT_ROOT = '/storage/emulated/0/Android/data/ru.iiec.pydroid3/files/sentiment_analysis'
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# --- Scrapers ---
try:
    from src.sentiment_analysis.scrapers.reddit_scraper import RedditScraper
    from src.sentiment_analysis.scrapers.twitter_scraper import TwitterScraper
    from src.sentiment_analysis.scrapers.crypto_panic_news_scraper import CryptoPanicNewsScraper
except ImportError as e:
    import logging as temp_logging
    temp_logging.basicConfig(level=temp_logging.ERROR)
    temp_logging.error(f"Critical import error for scrapers: {e}. Some functionalities might be unavailable.")

# --- Analysis Modules ---
# These modules fetch external data or perform other types of analysis.
# Note: These may still use LLMs internally, the change here only affects this script's direct analysis.
try:
    from src.analysis.fear_greed_index import get_fear_greed_index
    from src.analysis.dxy_strength import fetch_dxy_strength
    from src.analysis.macro_news_analyzer import fetch_and_analyze_macro_news
except ImportError as e:
    import logging as temp_logging
    temp_logging.basicConfig(level=temp_logging.ERROR)
    temp_logging.error(f"Critical import error for analysis modules: {e}. Some functionalities might be unavailable.")
    def get_fear_greed_index(*args, **kwargs): return []
    def fetch_dxy_strength(*args, **kwargs): return None
    def fetch_and_analyze_macro_news(*args, **kwargs): return []


# --- Project Utilities ---
try:
    from utils.logger import get_logger
    logger = get_logger("SentimentAnalysis")
except ImportError:
    import logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger("SentimentAnalysis_Fallback")
    logger.warning("Custom logger not found, using basic logging for SentimentAnalysis.")


# --- Constants ---
CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "credentials.yaml") # Path for scrapers if they need it explicitly
SENTIMENT_DATA_DIR = os.path.join(PROJECT_ROOT, "data", "sentiment")


def retry_request(func, *args, retries: int = 3, delay: int = 2, **kwargs) -> Any:
    """Helper function to retry network-bound functions."""
    for attempt in range(retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.warning(f"Attempt {attempt + 1}/{retries} failed for {func.__name__} with error: {e}")
            if attempt < retries - 1:
                time.sleep(delay * (attempt + 1))
            else:
                logger.error(f"Function {func.__name__} failed after {retries} attempts: {e}", exc_info=True)
                if func.__name__ in ["scrape", "fetch_news", "get_fear_greed_index", "fetch_and_analyze_macro_news"]:
                    return []
                elif func.__name__ == "fetch_dxy_strength":
                    return None
                return None
    return None


def analyze_posts(posts: List[Dict[str, Any]], source: str) -> List[Dict[str, Any]]:
    """
    Analyzes a list of posts for sentiment using TextBlob.
    Each post dictionary is updated with sentiment scores and categories.
    """
    analyzed: List[Dict[str, Any]] = []
    if not posts:
        logger.info(f"No posts from {source} to analyze.")
        return analyzed
        
    for post_idx, post in enumerate(posts):
        content = post.get("content", "")
        if not isinstance(content, str):
            logger.warning(f"Post content from {source} (item {post_idx+1}) is not a string: {content}. Using empty string.")
            content = ""

        sentiment_details: Dict[str, Any]

        if not content.strip():
            sentiment_details = {"score": 0.0, "category": "neutral", "error": "Empty content"}
        else:
            # Use TextBlob for sentiment analysis
            analysis = TextBlob(content)
            score = analysis.sentiment.polarity  # Polarity score from -1.0 to 1.0

            # Determine category based on polarity score
            category = "neutral"
            if score > 0.5: category = "bullish"
            elif score > 0.1: category = "mini bullish"
            elif score < -0.5: category = "bearish"
            elif score < -0.1: category = "mini bearish"

            sentiment_details = {
                "score": score,
                "category": category,
                "subjectivity": analysis.sentiment.subjectivity,
                "error": None
            }
        
        post["sentiment_score"] = sentiment_details.get("score", 0.0)
        post["sentiment_category"] = str(sentiment_details.get("category", "neutral")).lower()
        post["sentiment_analysis_details"] = sentiment_details
        
        post["source"] = source
        analyzed.append(post)
        logger.debug(f"Analyzed post {post_idx+1} from {source}. Score: {post['sentiment_score']}, Category: '{post['sentiment_category']}'")

    logger.info(f"Analyzed {len(analyzed)} posts from {source} using TextBlob.")
    return analyzed


def save_results(data: Dict[str, Any], output_path: str) -> None:
    """Saves the analysis results to a JSON file."""
    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        logger.info(f"Sentiment results saved to: {output_path}")
    except Exception as e:
        logger.exception(f"Failed to save sentiment results to {output_path}: {e}")


async def fetch_social_and_news_posts(coin_name: str, config_path_for_scrapers: str) -> tuple[List[Dict], List[Dict], List[Dict]]:
    """Fetches posts from Reddit, Twitter, and CryptoPanic concurrently."""
    loop = asyncio.get_running_loop()
    try:
        reddit_scraper = RedditScraper(config_path=config_path_for_scrapers)
        twitter_scraper = TwitterScraper(config_path=config_path_for_scrapers)
        cryptopanic_scraper = CryptoPanicNewsScraper(config_path=config_path_for_scrapers)
    except Exception as e:
        logger.error(f"Error initializing scrapers with config_path '{config_path_for_scrapers}': {e}. Scrapers may use defaults or fail.", exc_info=True)
        reddit_scraper = RedditScraper()
        twitter_scraper = TwitterScraper()
        cryptopanic_scraper = CryptoPanicNewsScraper()

    scraper_tasks = []
    with ThreadPoolExecutor(max_workers=3) as executor:
        if hasattr(reddit_scraper, 'scrape') and callable(reddit_scraper.scrape):
            scraper_tasks.append(loop.run_in_executor(executor, retry_request, reddit_scraper.scrape, coin_name, 20))
        else: scraper_tasks.append(asyncio.sleep(0, result=[])); logger.warning("Reddit scraper 'scrape' method not available.")

        if hasattr(twitter_scraper, 'scrape') and callable(twitter_scraper.scrape):
            scraper_tasks.append(loop.run_in_executor(executor, retry_request, twitter_scraper.scrape, coin_name, 20))
        else: scraper_tasks.append(asyncio.sleep(0, result=[])); logger.warning("Twitter scraper 'scrape' method not available.")

        if hasattr(cryptopanic_scraper, 'fetch_news') and callable(cryptopanic_scraper.fetch_news):
            scraper_tasks.append(loop.run_in_executor(executor, retry_request, cryptopanic_scraper.fetch_news, coin_name, 20))
        else: scraper_tasks.append(asyncio.sleep(0, result=[])); logger.warning("CryptoPanic scraper 'fetch_news' method not available.")
        
        results = await asyncio.gather(*scraper_tasks, return_exceptions=True)

    processed_results = []
    for i, res in enumerate(results):
        if isinstance(res, Exception):
            logger.error(f"Scraper task {i} failed with exception: {res}", exc_info=res)
            processed_results.append([])
        else:
            processed_results.append(res if isinstance(res, list) else [])
    
    reddit_posts_raw = processed_results[0] if len(processed_results) > 0 else []
    twitter_posts_raw = processed_results[1] if len(processed_results) > 1 else []
    cmc_articles_raw = processed_results[2] if len(processed_results) > 2 else []
    
    return reddit_posts_raw, twitter_posts_raw, cmc_articles_raw


async def get_sentiment_snapshot(symbol_or_coin_name: str) -> Dict[str, Any]:
    """
    Generates a comprehensive sentiment snapshot for a given cryptocurrency symbol or name.
    """
    coin_name_for_scrapers = symbol_or_coin_name.lower() 
    logger.info(f"Starting sentiment snapshot for: {symbol_or_coin_name} (using '{coin_name_for_scrapers}' for scraping)")
    start_time_total = time.time()

    try:
        # --- 1. Fetch social media and CryptoPanic news posts concurrently ---
        fetch_posts_start_time = time.time()
        reddit_posts_raw, twitter_posts_raw, cmc_articles_raw = await fetch_social_and_news_posts(coin_name_for_scrapers, CONFIG_PATH)
        logger.info(f"Fetched social/news posts for {symbol_or_coin_name} in {time.time() - fetch_posts_start_time:.2f}s. "
                    f"Reddit: {len(reddit_posts_raw)}, Twitter: {len(twitter_posts_raw)}, CryptoPanic: {len(cmc_articles_raw)}")

        # --- 2. Fetch macroeconomic data and market indicators concurrently ---
        logger.info("Fetching macroeconomic data and market indicators...")
        macro_market_start_time = time.time()
        loop = asyncio.get_running_loop()
        with ThreadPoolExecutor(max_workers=3) as macro_executor:
            macro_news_future = loop.run_in_executor(macro_executor, retry_request, fetch_and_analyze_macro_news, coin_name_for_scrapers)
            fear_greed_future = loop.run_in_executor(macro_executor, retry_request, get_fear_greed_index)
            dxy_strength_future = loop.run_in_executor(macro_executor, retry_request, fetch_dxy_strength)
            macro_news_data, fear_greed_data, dxy_strength_value = await asyncio.gather(macro_news_future, fear_greed_future, dxy_strength_future)
        
        macro_news_data = macro_news_data if isinstance(macro_news_data, list) else []
        fear_greed_data = fear_greed_data if isinstance(fear_greed_data, list) else []
        logger.info(f"Fetched macro data & market indicators in {time.time() - macro_market_start_time:.2f}s.")

        # --- 3. Prepare and Analyze Sentiment for Social Media Posts ---
        logger.info("Analyzing sentiments for social media and CryptoPanic posts with TextBlob...")
        analyzed_posts_combined: List[Dict[str, Any]] = []

        analyzed_posts_combined.extend(analyze_posts(reddit_posts_raw, "reddit"))
        analyzed_posts_combined.extend(analyze_posts(twitter_posts_raw, "twitter"))
        
        processed_cmc_articles_for_sentiment: List[Dict[str, Any]] = []
        for article in cmc_articles_raw:
            title = article.get("title", "")
            summary_or_slug = article.get("summary", article.get("slug", ""))
            article_content_for_sentiment = f"{title}. {summary_or_slug}".strip()
            article_copy = article.copy()
            article_copy["content"] = article_content_for_sentiment
            processed_cmc_articles_for_sentiment.append(article_copy)
        analyzed_posts_combined.extend(analyze_posts(processed_cmc_articles_for_sentiment, "cryptopanic"))
        
        valid_social_scores = [post.get("sentiment_score", 0.0) for post in analyzed_posts_combined if isinstance(post.get("sentiment_score"), (int, float))]
        average_social_sentiment_score = sum(valid_social_scores) / len(valid_social_scores) if valid_social_scores else 0.0

        overall_social_category = "neutral"
        if average_social_sentiment_score > 0.5: overall_social_category = "bullish"
        elif average_social_sentiment_score > 0.1: overall_social_category = "mini bullish"
        elif average_social_sentiment_score < -0.5: overall_social_category = "bearish"
        elif average_social_sentiment_score < -0.1: overall_social_category = "mini bearish"

        # --- 4. Construct the final result ---
        current_fear_greed_index_details = fear_greed_data[0] if fear_greed_data and isinstance(fear_greed_data[0], dict) else None

        result = {
            "snapshot_timestamp_utc": datetime.utcnow().isoformat(),
            "symbol_analyzed": symbol_or_coin_name,
            "average_social_sentiment_score": round(average_social_sentiment_score, 4),
            "overall_social_sentiment_category": overall_social_category,
            "fear_greed_index": current_fear_greed_index_details,
            "dxy_strength_score": dxy_strength_value if isinstance(dxy_strength_value, (float, int)) else None,
            "macro_economic_news": macro_news_data,
            "total_social_posts_analyzed": len(analyzed_posts_combined),
            "source_breakdown": {
                "reddit_posts_fetched": len(reddit_posts_raw),
                "twitter_tweets_fetched": len(twitter_posts_raw),
                "cryptopanic_articles_fetched": len(cmc_articles_raw)
            },
        }

        # --- 5. Save results to a file ---
        output_filename = f"{symbol_or_coin_name.replace('/', '_')}_sentiment_snapshot_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        output_path = os.path.join(SENTIMENT_DATA_DIR, output_filename)
        save_results(result, output_path)

        logger.info(f"Sentiment snapshot for {symbol_or_coin_name} completed in {time.time() - start_time_total:.2f} seconds.")
        return result

    except Exception as e:
        logger.exception(f"Error generating sentiment snapshot for {symbol_or_coin_name}: {e}")
        return {
            "error": str(e),
            "symbol_analyzed": symbol_or_coin_name,
            "snapshot_timestamp_utc": datetime.utcnow().isoformat(),
        }


async def run_sentiment_analysis_for_symbol(symbol: str) -> Dict[str, Any]:
    """Helper function to run sentiment analysis for a single symbol."""
    logger.info(f"Queuing sentiment analysis for symbol: {symbol}")
    analysis_result = await get_sentiment_snapshot(symbol)
    return analysis_result


if __name__ == "__main__":
    test_symbol_input = input("enter a coin name: ")
    
    print(f"\nRunning sentiment analysis for: {test_symbol_input} using TextBlob...")
    
    try:
        final_result_for_test = asyncio.run(run_sentiment_analysis_for_symbol(test_symbol_input))
        
        print("\n--- Sentiment Analysis Result (Summary) ---")
        if final_result_for_test.get("error"):
            print(f"Error: {final_result_for_test['error']}")
        else:
            print(f"Symbol Analyzed: {final_result_for_test.get('symbol_analyzed')}")
            print(f"Timestamp UTC: {final_result_for_test.get('snapshot_timestamp_utc')}")
            print(f"Avg. Social Sentiment Score: {final_result_for_test.get('average_social_sentiment_score')}")
            print(f"Overall Social Sentiment Category: {final_result_for_test.get('overall_social_sentiment_category')}")
            
            fg_index = final_result_for_test.get('fear_greed_index')
            if fg_index and isinstance(fg_index, dict):
                print(f"Fear & Greed Index: {fg_index.get('value')} ({fg_index.get('value_classification')})")
            else:
                print(f"Fear & Greed Index: Data unavailable")

            print(f"DXY Strength Score: {final_result_for_test.get('dxy_strength_score', 'N/A')}")
            print(f"Total Social Posts Analyzed: {final_result_for_test.get('total_social_posts_analyzed')}")
            print(f"Macro News Articles Fetched: {len(final_result_for_test.get('macro_economic_news', []))}")

    except Exception as e:
        logger.critical(f"An error occurred during the __main__ test run for {test_symbol_input}: {e}", exc_info=True)
        print(f"\nAn unexpected error occurred in the main test execution: {e}")

    print("\n--- End of Test Run ---")