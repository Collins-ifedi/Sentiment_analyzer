# sentiment_utils.py

import re
import sys
import logging
from typing import Dict, Any

# Import TextBlob for local sentiment analysis
from textblob import TextBlob

# --- Path Setup ---
# Pydroid path (ensure this is correct for your environment)
PROJECT_ROOT = '/storage/emulated/0/Android/data/ru.iiec.pydroid3/files/cryptsignal'
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# --- Logger Setup ---
try:
    from utils.logger import get_logger
    logger = get_logger("SentimentUtils")
except ImportError:
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger("SentimentUtils_Fallback")
    logger.warning("Custom logger not found, using basic logging for SentimentUtils.")


def clean_text(text: str) -> str:
    """
    Cleans the input text by removing URLs and other noise.
    """
    if not isinstance(text, str):
        return ""
    # Remove URLs
    text = re.sub(r"http\S+", "", text)
    # Basic cleaning: remove non-alphanumeric and non-essential punctuation
    text = re.sub(r"[^\w\s\.,'!\?\$\%\@\#\&\*]", "", text)
    return text.strip()


def hybrid_sentiment(text: str) -> Dict[str, Any]:
    """
    Analyzes the sentiment of the given text using TextBlob.

    This function cleans the text, calculates the sentiment polarity, and categorizes
    it as bullish, bearish, or neutral based on the polarity score.

    Args:
        text: The input text to analyze.

    Returns:
        A dictionary containing the sentiment 'score' (float between -1.0 and 1.0),
        'category' (string), and 'error' (None, as TextBlob does not raise errors
        for sentiment analysis on valid strings).
    """
    cleaned_text = clean_text(text)
    if not cleaned_text:
        return {"score": 0.0, "category": "neutral", "error": "Input text was empty after cleaning."}

    try:
        # Perform sentiment analysis using TextBlob
        analysis = TextBlob(cleaned_text)
        score = analysis.sentiment.polarity  # Returns a float from -1.0 to 1.0

        # Determine the category based on the polarity score
        category = "neutral"
        if score > 0.5:
            category = "bullish"
        elif score > 0.1:
            category = "mini bullish"
        elif score < -0.5:
            category = "bearish"
        elif score < -0.1:
            category = "mini bearish"

        logger.debug(f"Analyzed text with TextBlob. Score: {score:.2f}, Category: {category}")

        return {
            "score": score,
            "category": category,
            "error": None
        }
    except Exception as e:
        logger.error(f"An unexpected error occurred during TextBlob analysis: {e}", exc_info=True)
        return {"score": 0.0, "category": "neutral", "error": f"Unexpected TextBlob error: {e}"}


# --- Example Usage ---
if __name__ == "__main__":
    print("\n" + "="*60)
    print("Testing sentiment_utils.py with local TextBlob analysis.")
    print("="*60 + "\n")

    test_texts = [
        ("This is a great day for Bitcoin, price is soaring!", "Expected: bullish"),
        ("I think BTC might go up a bit more soon.", "Expected: mini bullish"),
        ("The market is stable, nothing much happening with Ethereum.", "Expected: neutral"),
        ("Feeling a bit worried about the short-term dip in Solana.", "Expected: mini bearish"),
        ("Complete disaster for altcoins, everything is crashing hard!", "Expected: bearish"),
        ("Crypto is the future, to the moon! 🚀🚀", "Expected: bullish"),
        ("Not sure what to think about the market right now.", "Expected: neutral"),
        ("", "Expected: neutral (empty string)"),
        ("This is an extremely positive outlook for the entire crypto space, expecting massive gains across the board!", "Expected: bullish"),
        ("Slightly negative sentiment observed due to recent FUD, but fundamentals remain okay.", "Expected: mini bearish")
    ]

    for i, (text, expected) in enumerate(test_texts):
        print(f"--- Test Case {i+1} ---")
        print(f"Input Text: \"{text}\" (Expected sentiment hint: {expected})")
        result = hybrid_sentiment(text)
        # Using .get() provides a safe way to access keys that might be missing on error
        print(f"Sentiment Result: Score = {result.get('score'):.2f}, Category = '{result.get('category')}', Error = {result.get('error')}")
        print("-" * 20 + "\n")